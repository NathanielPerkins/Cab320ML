#!/usr/bin/env python

import pickle
import numpy


#### Load the data
fp            = open('two_cluster_example.pickle','r')
(X1,X2)       = pickle.load(fp);
fp.close();
X             = numpy.vstack((X1, X2))

#### Set the initial guess at to what the means should be
init_means    = numpy.array([[-2.,0.],[1.,-1]])
